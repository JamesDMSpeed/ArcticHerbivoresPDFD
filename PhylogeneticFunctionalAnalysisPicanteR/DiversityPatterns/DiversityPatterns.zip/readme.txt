Folder contains maps of Arctic vertebrate herbivore species richness, phylogenetic diversity, functional diversity and functional divergence.
Files with suffixes _es are the effect sizes.
Files with suffixes _rank are the rank of observed diversity against randomisted estimates. 